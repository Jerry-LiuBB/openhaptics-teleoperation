/*****************************************************************************

Copyright (c) 2004 SensAble Technologies, Inc. All rights reserved.

OpenHaptics(TM) toolkit. The material embodied in this software and use of
this software is subject to the terms and conditions of the clickthrough
Development License Agreement.

For questions, comments or bug reports, go to forums at: 
    http://dsc.sensable.com

Module Name:
  
  QueryDevice.c

Description:

  This example demonstrates how to retrieve information from the haptic device.

*******************************************************************************/
#ifdef  _WIN64
#pragma warning (disable:4996)
#endif

#if defined(WIN32)
# include <windows.h>
# include <conio.h>
#else
# include "conio.h"
# include <string.h>
#endif

#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <cjson/cJSON.h>  // 用于构建JSON

#include <HD/hd.h>

#include <HDU/hduVector.h>
#include <HDU/hduError.h>

/* Holds data retrieved from HDAPI. */
#define MAX_INPUT_DOF   6   
#define MAX_OUTPUT_DOF  6

static int gNumMotors = 0;
static int gNumEncoders = 0;

/* 全局连接参数 */
static char gArmIP[16] = "192.168.1.19";  // 默认IP
static int gArmPort = 8080;               // 默认端口
static int gSockfd = -1;                  // socket文件描述符

// 全局状态变量
static bool gArmRunning = false;
static bool gArmLocked = false;

/* Holds data retrieved from HDAPI. */

struct OmniState {
   hduVector3Dd position;  //3x1 vector of position
   hduVector3Dd velocity;  //3x1 vector of velocity
   hduVector3Dd inp_vel1;  //3x1 history of velocity used for filtering velocity estimate
   hduVector3Dd inp_vel2;
   hduVector3Dd inp_vel3;
   hduVector3Dd out_vel1;
   hduVector3Dd out_vel2;
   hduVector3Dd out_vel3;
   hduVector3Dd pos_hist1; //3x1 history of position used for 2nd order backward difference estimate of velocity
   hduVector3Dd pos_hist2;
   // hduQuaternion rot;
   hduVector3Dd joints;
   hduVector3Dd force;   //3 element double vector force[0], force[1], force[2]
   float thetas[7];
   int buttons[2];
   int buttons_prev[2];
   //bool lock;
   //bool close_gripper;
   hduVector3Dd lock_pos;
   double units_ratio;
};

typedef struct
{
   HDboolean m_buttonState;       /* Has the device button has been pressed. */
   HDboolean n_buttonState;
   hduVector3Dd m_devicePosition; /* Current device coordinates. */
   HDErrorInfo m_error;
   hduVector3Dd joints;
   float thetas[7];
   float pos[6];
   float rm_force[6];
   float rm_zero_force[6];
   float work_zero[6];
   float tool_zero[6];
} DeviceData;

static DeviceData gServoDeviceData;

HDSchedulerHandle gCallbackHandle = HD_INVALID_HANDLE;

/* 初始化网络连接 */
bool init_network_connection() {  // 不再需要参数
    struct sockaddr_in serv_addr;
    struct hostent *server;
    
    gSockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (gSockfd < 0) {
        perror("ERROR opening socket");
        return false;
    }
    
    server = gethostbyname(gArmIP);  // 使用全局IP
    if (server == NULL) {
        fprintf(stderr, "ERROR, no such host: %s\n", gArmIP);
        close(gSockfd);
        gSockfd = -1;
        return false;
    }
    
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    memcpy(&serv_addr.sin_addr.s_addr, server->h_addr, server->h_length);
    serv_addr.sin_port = htons(gArmPort);  // 使用全局端口
    
    struct timeval tv;
    tv.tv_sec = 1;
    tv.tv_usec = 0;
    setsockopt(gSockfd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    
    if (connect(gSockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("ERROR connecting");
        close(gSockfd);
        gSockfd = -1;
        return false;
    }
    
    char ip_str[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &(serv_addr.sin_addr), ip_str, INET_ADDRSTRLEN);
    printf("机械臂连接成功，IP: %s:%d\n", ip_str, gArmPort);
    
    return true;
}

/* 设置机械臂连接参数 */
void set_arm_connection_params(const char* ip, int port) {
    strncpy(gArmIP, ip, sizeof(gArmIP)-1);
    gArmIP[sizeof(gArmIP)-1] = '\0';  // 确保字符串终止
    gArmPort = port;
    printf("机械臂参数已设置 - IP: %s, Port: %d\n", gArmIP, gArmPort);
}

// /* 关闭网络连接 */
void close_network_connection() {
    if (gSockfd >= 0) {
        close(gSockfd);
        gSockfd = -1;
    }
}

// 从arm_config.txt文件读取机械臂IP和端口
void load_connection_config(const char* config_file) {
    FILE* fp = fopen(config_file, "r");
    if (fp) {
        char ip[16];
        int port;
        if (fscanf(fp, "%15s %d", ip, &port) == 2) {
            set_arm_connection_params(ip, port);
        }
        fclose(fp);
    }
}

/* 发送JSON命令（使用持久连接） */
int send_json_command(const char *json_str) {
    if (gSockfd < 0) {
        fprintf(stderr, "Socket connection not established\n");
        return -1;
    }
    
    int total = strlen(json_str);
    int sent = 0;
    int bytes;
    
    while (sent < total) {
        bytes = write(gSockfd, json_str + sent, total - sent);
        if (bytes < 0) {
            perror("ERROR writing to socket");
            close_network_connection();  // 发生错误时关闭连接
            return -1;
        }
        if (bytes == 0) break;
        sent += bytes;
    }
    
    printf("发送成功: %d bytes\n", sent);
    return 0;
}

/* 创建hand_follow_pos命令的JSON字符串 */
char* create_gripper_command(int hand_pos) {
    cJSON *root = cJSON_CreateObject();
    if (!root) return NULL;
    
    cJSON_AddStringToObject(root, "command", "hand_follow_pos");
    
    // 修改为数组格式
    cJSON *pos_array = cJSON_CreateArray();
    cJSON_AddItemToArray(pos_array, cJSON_CreateNumber(hand_pos));
    cJSON_AddItemToObject(root, "hand_pos", pos_array);
    
    char *json_str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return json_str;
}

/* 创建末端生态协议设置命令的JSON字符串 */
char* send_rm_plus_mode_command() {
    const char* json_command = "{\"command\":\"set_rm_plus_mode\",\"mode\":115200}";
    
    if (send_json_command(json_command) != 0) {
        fprintf(stderr, "Failed to send JSON command\n");
        if (!init_network_connection()) {
            fprintf(stderr, "Reconnection to %s:%d failed\n", gArmIP, gArmPort);
        }
        return NULL;  // 失败返回NULL
    }
    
    // 成功则返回字符串的拷贝
    return strdup(json_command);  // 需要调用者负责free()
}

/* 创建movej命令的JSON字符串 */
char* create_movej_command(int pos[6]) {
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "command", "movej");
    
    // 创建joint数组
    cJSON *joint = cJSON_CreateArray();
    for (int i = 0; i < 6; i++) {
        cJSON_AddItemToArray(joint, cJSON_CreateNumber(pos[i]));
    }
    cJSON_AddItemToObject(root, "joint", joint);
    
    cJSON_AddNumberToObject(root, "v", 50);
    cJSON_AddNumberToObject(root, "r", 0);
    cJSON_AddNumberToObject(root, "trajectory_connect", 0);
    
    char *json_str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return json_str;
}

/* 创建movej_canfd命令的JSON字符串 */
char* create_movej_canfd_command(int pos[6]) {
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "command", "movej_canfd");
    
    // 创建joint数组
    cJSON *joint = cJSON_CreateArray();
    for (int i = 0; i < 6; i++) {
        cJSON_AddItemToArray(joint, cJSON_CreateNumber(pos[i]));
    }
    cJSON_AddItemToObject(root, "joint", joint);
    
    cJSON_AddBoolToObject(root, "follow", true);
    cJSON_AddNumberToObject(root, "trajectory_mode", 0);
    cJSON_AddNumberToObject(root, "radio", 0);
    
    char *json_str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return json_str;
}

/* 接收机械臂响应并检查状态 */
bool check_trajectory_complete() {
    if (gSockfd < 0) return false;

    char buffer[1024] = {0};
    fd_set read_fds;
    struct timeval tv;
    
    FD_ZERO(&read_fds);
    FD_SET(gSockfd, &read_fds);
    tv.tv_sec = 1;  // 1秒超时
    tv.tv_usec = 0;

    // 检查是否有数据可读
    int ret = select(gSockfd + 1, &read_fds, NULL, NULL, &tv);
    if (ret <= 0) {
        return false;  // 超时或错误
    }

    // 读取响应数据
    int bytes = read(gSockfd, buffer, sizeof(buffer) - 1);
    if (bytes <= 0) {
        return false;
    }
    buffer[bytes] = '\0';

    // 解析JSON响应
    cJSON *root = cJSON_Parse(buffer);
    if (!root) {
        return false;
    }

    cJSON *trajectory_state = cJSON_GetObjectItem(root, "trajectory_state");
    bool complete = (trajectory_state && cJSON_IsFalse(trajectory_state));
    
    cJSON_Delete(root);
    return complete;
}

/* Movej_CANFD函数实现 */
int Movej_CANFD(float *joint, float expand, bool follow, uint8_t trajectory_mode, uint8_t radio)
{
    cJSON *root, *array;
    char *data;
    char buffer[200];
    int res, i;
    
    // 创建根节点对象
    root = cJSON_CreateObject();
    array = cJSON_CreateArray();
    
    // 数组加入数据 - 修正为正确的数组添加方式
    for (i = 0; i < 6; i++) {
        cJSON_AddItemToArray(array, cJSON_CreateNumber((int)(joint[i] * 1000)));
    }
    
    // 加入字符串对象
    cJSON_AddStringToObject(root, "command", "movej_canfd");
    cJSON_AddItemToObject(root, "joint", array);
    
    if(follow == false) {
        cJSON_AddFalseToObject(root, "follow");
    } else {
        cJSON_AddTrueToObject(root, "follow");
    }
    
    cJSON_AddNumberToObject(root, "trajectory_mode", trajectory_mode);
    cJSON_AddNumberToObject(root, "radio", radio);

    data = cJSON_Print(root);
    sprintf(buffer, "%s\r\n", data);
    
    // 发送数据
    res = send_json_command(buffer);
    
    cJSON_Delete(root);
    free(data);

    if (res < 0) {
        return 1;
    }
    return 0;
}

HDCallbackCode HDCALLBACK updateDeviceCallback(void *pUserData) {
    int nButtons = 0;
    hdBeginFrame(hdGetCurrentDevice());

    // 获取设备状态
    hdGetIntegerv(HD_CURRENT_BUTTONS, &nButtons);
    gServoDeviceData.m_buttonState = (nButtons & HD_DEVICE_BUTTON_1) ? HD_TRUE : HD_FALSE;
    gServoDeviceData.n_buttonState = (nButtons & HD_DEVICE_BUTTON_2) ? HD_TRUE : HD_FALSE;
    
    hdGetDoublev(HD_CURRENT_POSITION, gServoDeviceData.m_devicePosition);
    hdGetDoublev(HD_CURRENT_JOINT_ANGLES, gServoDeviceData.joints);
    
    hduVector3Dd gimbal_angles;
    hdGetDoublev(HD_CURRENT_GIMBAL_ANGLES, gimbal_angles);

    // 更新关节角度
    float t[7] = {0., gServoDeviceData.joints[0], gServoDeviceData.joints[1],
                  gServoDeviceData.joints[2] - gServoDeviceData.joints[1],
                  gimbal_angles[0], gimbal_angles[1], gimbal_angles[2]};
    for (int i = 0; i < 7; i++) {
        gServoDeviceData.thetas[i] = t[i];
    }

    gServoDeviceData.m_error = hdGetError();
    hdEndFrame(hdGetCurrentDevice());
    return HD_CALLBACK_CONTINUE;
}


/*******************************************************************************
 Checks the state of the gimbal button and gets the position of the device.
*******************************************************************************/
HDCallbackCode HDCALLBACK copyDeviceDataCallback(void *pUserData)
{
    DeviceData *pDeviceData = (DeviceData *) pUserData;

    memcpy(pDeviceData, &gServoDeviceData, sizeof(DeviceData));

    return HD_CALLBACK_DONE;
}


/*******************************************************************************
 Prints out a help string about using this example.
*******************************************************************************/
void printHelp(void)
{
    static const char help[] = {"\
按钮1逻辑：\n\
- 未运行状态下长按3秒：切换到运行状态并开启透传跟随\n\
- 运行状态下长按3秒：切换到未运行状态并运动到复位位置\n\
- 运行状态下短按：运动停止/恢复跟随切换\n\
按钮2逻辑：\n\
- 按下状态：夹爪闭合\n\
- 抬起状态：夹爪松开\n"};

    fprintf(stdout, "%s\n", help);
}

void mainLoop(void) {
    static const int kTerminateCount = 3000; // 3秒计数（假设1000次/秒）
    int mbuttonHoldCount = 0;
    int Count = 0;
    bool movej_flag = false;
    bool movej_canfd_flag = false;
    bool reset_flag = false;
    DeviceData currentData;
    DeviceData prevData;

    hdScheduleSynchronous(copyDeviceDataCallback, &currentData, HD_MIN_SCHEDULER_PRIORITY);
    memcpy(&prevData, &currentData, sizeof(DeviceData));    

    printHelp();

    while (1) {
        hdScheduleSynchronous(copyDeviceDataCallback, &currentData, HD_MIN_SCHEDULER_PRIORITY);
        Count++;
        
        // 设置关节映射关系
        gServoDeviceData.pos[0] = -gServoDeviceData.thetas[1] * 70 *1000;       //-0.35~1.75
        gServoDeviceData.pos[1] = (60 - (45 * gServoDeviceData.thetas[2])) *1000;//-1.745~0.088
        gServoDeviceData.pos[2] = (85 - (45 * gServoDeviceData.thetas[3]))*1000;//-0.0025~0.748
        gServoDeviceData.pos[3] = -gServoDeviceData.thetas[4] * 30 *1000;//2.885~-2.24
        gServoDeviceData.pos[4] = (70 - (20 * gServoDeviceData.thetas[5]))*1000;//-0.519~2.04
        gServoDeviceData.pos[5] = gServoDeviceData.thetas[6] * 30*1000;//-2.5745~2.7268
        
        // 透传跟随模式
        if (movej_canfd_flag && gArmRunning && Count % 10 == 0)
        {
            float joint_positions[6];
            for (int i = 0; i < 6; i++) {
                joint_positions[i] = gServoDeviceData.pos[i] / 1000.0f;
            }
            
            printf("当前位置:\n%f\n%f\n%f\n%f\n%f\n%f\n", 
                joint_positions[0], joint_positions[1], joint_positions[2],
                joint_positions[3], joint_positions[4], joint_positions[5]);
            
            if (Movej_CANFD(joint_positions, 0.0f, true, 0, 0) != 0) {
                fprintf(stderr, "Movej_CANFD命令发送失败\n");
            }
        }
        
        // 普通运动模式
        if (movej_flag && !reset_flag)
        {
            int current_pos[6];
            for (int i = 0; i < 6; i++) {
                current_pos[i] = (int)gServoDeviceData.pos[i];
            }
            char *movej_cmd = create_movej_command(current_pos);
            if (send_json_command(movej_cmd) != 0) {
                fprintf(stderr, "运动命令发送失败\n");
            }
            free(movej_cmd);
            movej_flag = false;
        }
        
        // 按钮1逻辑处理
        if (currentData.m_buttonState && !prevData.m_buttonState) {
            // 按钮按下事件
            printf("按钮1按下\n");
        } 
        else if (currentData.m_buttonState && prevData.m_buttonState) {
            // 按钮持续按住
            mbuttonHoldCount++;
            
            // 显示长按进度
            if (mbuttonHoldCount % 1000 == 0) {
                printf("长按中: %.1f秒\n", mbuttonHoldCount / 1000.0f);
            }
        }
        else if (!currentData.m_buttonState && prevData.m_buttonState) {
            // 按钮释放
            if (mbuttonHoldCount > kTerminateCount) {
                // 长按3秒以上
                if (!gArmRunning) {
                    // 未运行 -> 运行：开启透传跟随
                    gArmRunning = true;
                    gArmLocked = false;
                    movej_canfd_flag = true;
                    printf("切换到运行状态：开启透传跟随\n");
                } else {
                    // 运行 -> 未运行：运动到复位位置
                    gArmRunning = false;
                    movej_canfd_flag = false;
                    
                    // 发送复位命令（所有关节归零）
                    int reset_pos[6];
                    for (int i = 0; i < 6; i++) {
                        reset_pos[i] = 0;
                    }
                    char *reset_cmd = create_movej_command(reset_pos);
                    if (send_json_command(reset_cmd) != 0) {
                        fprintf(stderr, "复位命令发送失败\n");
                    }
                    free(reset_cmd);
                    printf("切换到未运行状态：运动到复位位置\n");
                }
            } else if (mbuttonHoldCount > 0) {
                // 短按（小于3秒）
                if (gArmRunning) {
                    // 运行状态下短按：切换锁定状态
                    gArmLocked = !gArmLocked;
                    
                    if (gArmLocked) {
                        // 运动停止：发送当前位置命令锁定位置
                        int current_pos[6];
                        for (int i = 0; i < 6; i++) {
                            current_pos[i] = (int)gServoDeviceData.pos[i];
                        }
                        char *lock_cmd = create_movej_command(current_pos);
                        if (send_json_command(lock_cmd) != 0) {
                            fprintf(stderr, "锁定命令发送失败\n");
                        }
                        free(lock_cmd);
                        movej_canfd_flag = false;
                        printf("运动停止\n");
                    } else {
                        // 恢复跟随
                        movej_canfd_flag = true;
                        printf("恢复跟随\n");
                    }
                }
            }
            
            mbuttonHoldCount = 0; // 重置计数器
        }
        
        // 按钮2（夹爪控制）
        if (currentData.n_buttonState != prevData.n_buttonState) {
            int pos = currentData.n_buttonState ? 12000 : 0; // 12000闭合，0松开
            
            printf("夹爪%s\n", currentData.n_buttonState ? "闭合" : "松开");
            
            char *json_command = create_gripper_command(pos);
            if (json_command) {
                if (send_json_command(json_command) != 0) {
                    fprintf(stderr, "夹爪命令发送失败\n");
                }
                free(json_command);
            }
        }

        // 错误检查
        if (HD_DEVICE_ERROR(currentData.m_error)) {
            hduPrintError(stderr, &currentData.m_error, "设备错误");
            if (hduIsSchedulerError(&currentData.m_error)) {
                break;
            }
        }

        memcpy(&prevData, &currentData, sizeof(DeviceData));
        
        // 添加短暂延迟以减少CPU占用
        usleep(1000); // 1ms延迟
    }
}

/*******************************************************************************
 Main function.
 Sets up the device, runs main application loop, cleans up when finished.
*******************************************************************************/
int main(int argc, char* argv[])
{
    HDSchedulerHandle hUpdateHandle = 0;
    HDErrorInfo error;

    /* Initialize the device, must be done before attempting to call any hd 
       functions. */
    HHD hHD = hdInitDevice(HD_DEFAULT_DEVICE);
    if (HD_DEVICE_ERROR(error = hdGetError()))
    {
        hduPrintError(stderr, &error, "Failed to initialize the device");
        fprintf(stderr, "\nPress any key to quit.\n");
        getch();
        return -1;           
    }

    /* Schedule the main scheduler callback that updates the device state. */
    hUpdateHandle = hdScheduleAsynchronous(
        updateDeviceCallback, 0, HD_MAX_SCHEDULER_PRIORITY);

    /* Start the servo loop scheduler. */
    hdStartScheduler();
    if (HD_DEVICE_ERROR(error = hdGetError()))
    {
        hduPrintError(stderr, &error, "Failed to start the scheduler");
        fprintf(stderr, "\nPress any key to quit.\n");
        getch();
        return -1;           
    }

    load_connection_config("arm_config.txt");

    if (!init_network_connection()) {  
        fprintf(stderr, "Failed to initialize network connection\n");
        getch();
        hdStopScheduler();
        hdUnschedule(hUpdateHandle);
        hdDisableDevice(hHD);
        return -1;
    }
    // 设置末端生态模式
    char *json_response = send_rm_plus_mode_command();
    if (json_response) {
        printf("Sent command: %s\n", json_response);
        free(json_response);
    }

    /* Run the application loop. */
    mainLoop();

    /* For cleanup, unschedule callbacks and stop the servo loop. */
    hdStopScheduler();
    hdUnschedule(hUpdateHandle);
    hdDisableDevice(hHD);

    /* Close network connection */
    close_network_connection();

    return 0;
}